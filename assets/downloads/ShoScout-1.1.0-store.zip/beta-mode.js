globalThis.ShoSentinelBetaMode=Object.freeze({enabled:true,monitorLimit:100,batchCapture:false,workbench:false});
